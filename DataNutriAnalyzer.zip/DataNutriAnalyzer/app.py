import streamlit as st
import pandas as pd
import plotly.express as px
from data_processor import load_and_process_data
from visualizations import (
    create_distribution_plot,
    create_correlation_plot,
    create_category_comparison,
    create_scatter_matrix
)

# Page config
st.set_page_config(
    page_title="Nutritional Data Analysis Research",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load and process data
@st.cache_data
def get_data():
    return load_and_process_data()

# Load data
df = get_data()

if df is not None:
    st.title("Nutritional Data Analysis Research Dashboard")

    st.markdown("""
    ### Nutrition Data Analysis and Health Outcomes Research

    This research dashboard provides comprehensive analysis of nutritional data and its impact 
    on health outcomes using advanced statistical methods and machine learning models.
    """)

    # Display key metrics
    st.header("Research Overview")
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Total Food Items", len(df))
    with col2:
        st.metric("Nutrient Categories", len(df['Category'].unique()))
    with col3:
        avg_calories = df['Calories'].mean()
        st.metric("Average Caloric Content", f"{avg_calories:.1f} kcal")

    # Sidebar filters
    st.sidebar.header("Filters")
    selected_category = st.sidebar.selectbox(
        "Select Food Category",
        ["All"] + sorted(df["Category"].unique().tolist())
    )

    # Filter data based on selection
    filtered_df = df[df["Category"] == selected_category] if selected_category != "All" else df

    # Nutrient selection
    nutrients = ['Calories', 'Protein', 'Fat', 'Carbs', 'Fiber']

    # Distribution Analysis
    st.header("Nutrient Distribution Analysis")
    selected_nutrient = st.selectbox("Select Nutrient for Analysis", nutrients)

    try:
        dist_plot = create_distribution_plot(filtered_df, selected_nutrient)
        if dist_plot:
            st.plotly_chart(dist_plot, use_container_width=True)
    except Exception as e:
        st.error(f"Error creating distribution plot: {str(e)}")

    # Correlation Analysis
    st.header("Nutrient Correlation Analysis")
    try:
        corr_plot = create_correlation_plot(filtered_df[nutrients])
        if corr_plot:
            st.plotly_chart(corr_plot, use_container_width=True)
    except Exception as e:
        st.error(f"Error creating correlation plot: {str(e)}")

    # Category-wise Analysis
    if selected_category == "All":
        st.header("Category-wise Analysis")
        try:
            cat_plot = create_category_comparison(df, nutrients)
            if cat_plot:
                st.plotly_chart(cat_plot, use_container_width=True)
        except Exception as e:
            st.error(f"Error creating category comparison: {str(e)}")

    # Scatter Matrix
    st.header("Nutrient Relationships")
    try:
        scatter_plot = create_scatter_matrix(filtered_df, nutrients)
        if scatter_plot:
            st.plotly_chart(scatter_plot, use_container_width=True)
    except Exception as e:
        st.error(f"Error creating scatter matrix: {str(e)}")

    # Raw Data View
    if st.checkbox("Show Raw Data"):
        st.header("Raw Data")
        st.dataframe(filtered_df)

else:
    st.error("Error loading the dataset. Please check the data file and try again.")