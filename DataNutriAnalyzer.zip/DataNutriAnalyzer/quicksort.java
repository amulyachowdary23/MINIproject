import java.util.Scanner;
public class quick{
public static void main(String[] args){
    Scanner sc =new Scanner(System.in);
    int[] arr=sc.nextInt();
    for(int i=0;i<arr;i++){
        i++;
    }
    int n=arr.length[];
    int x=arr[0];
    int y=arr[n-1];
    if(x>y){
        
    }
}
}